#include<stdlib.h>
#include<stdio.h>
int main()
{
	int val = 65;
	printf("Number: %4d, %x, %o, %c \n", val, val, val, (char)val);
	return EXIT_SUCCESS;
}
