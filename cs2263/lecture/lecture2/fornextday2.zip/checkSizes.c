#include<stdlib.h>
#include<stdio.h>

int main()
{
	char exChar;
	int exInt;
	float exFloat;
	double exDouble;

	printf("Size of char: %d \n", sizeof(exChar));
	printf("Size of int: %d \n", sizeof(exInt));
	printf("Size of float: %d \n", sizeof(exFloat));
	printf("Size of double: %d \n", sizeof(exDouble));

	return EXIT_SUCCESS;
}
