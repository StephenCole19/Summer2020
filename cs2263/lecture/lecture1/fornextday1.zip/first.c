#include <stdio.h>
#include <stdlib.h>

int main(int argc, char * * argv)
{
	int a = 5;
	int b = 17;
	printf("main a = %d, b = %d, argc = %d\n", a, b, argc);
	return EXIT_SUCCESS;
}
